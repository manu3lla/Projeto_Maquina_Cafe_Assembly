# MaquinaCafe
Julian Ryu Takeda R.A: 22.224.030-1
Manuella Filipe Peres R.A: 22.224.029-3
Projeto: Simulação de uma Cafeteira no EdSim51DI

O objetivo deste projeto é criar uma simulação de uma cafeteira utilizando o simulador EdSim51DI, permitindo que o usuário escolha o tipo de café desejado através do teclado, com feedback visual por meio dos LEDs e exibição no display. O fluxo de interação inclui a escolha do café, a indicação de que a preparação está em andamento e, por fim, a confirmação de que o pedido está pronto.
